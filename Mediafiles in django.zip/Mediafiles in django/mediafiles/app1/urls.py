from django.urls import path
from app1.views import StudentView, showstudent, updateview

urlpatterns = [
    path('sv/', StudentView, name="studenturl"),
    path('ss/', showstudent, name='showstudenturl'),
    path('up/<int:id>/', updateview, name='updateurl')
]