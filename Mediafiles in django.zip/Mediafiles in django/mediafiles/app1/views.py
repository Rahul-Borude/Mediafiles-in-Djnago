from django.shortcuts import render, redirect
from app1.models import Student
from app1.forms import StudentForm


# Create your views here.
def StudentView(request):
    form = StudentForm()
    template_name = "app1/image.html"

    if request.method == "POST":
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
    context = {'form':form}
    return render(request, template_name, context)

def showstudent(request):
    var = Student.objects.all()
    template_name = "app1/showstudent.html"
    context = {'order':var}
    return render(request, template_name, context)

def updateview(request,id):
    obj = Student.objects.get(id=id)
    form = StudentForm(instance=obj)
    template_name = "app1/image.html"
    if request.method == "POST":
        form = StudentForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            return redirect('studenturl')
    context = {'form':form}
    return render(request, template_name, context)


